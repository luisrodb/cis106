# Notes 1

## What is Markdown?
This is a computer language that uses tags to define elements within a document. It only contains standard words, rather than the typical programing syntax.


## What is Git?
It is a distrubuted version control system designed to help developers manage and track changes to their codebase effectively.


## What is GitHub?
This one is basicallly the garage where teams all gather to build together. It builds on Git's local capabilities by offering a cloud-based platform for hosting Git repositories; turning individual effort into collective progress.


## What is Slack?
This one is a messaging and collaboration platform used by teams to communicate, organize projects, and centralize information in a single searchable space. This app replaces emails with organized "channels", file sharing, and other integration with other tools.